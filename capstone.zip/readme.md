# Machine Learning Engineer Nanodegree
# Capstone Project
## Project: Diabetes prediction

This project is a supervised learning problem. This project reviews various supervised machine learning classification approaches used to predict whether a person is suffering from diabetes or not.
Random Forest classifier algorithm is applied to obtain fscore of 98%.

### Install

This project requires **Python 3** and the following Python libraries installed:

- [NumPy](http://www.numpy.org/)
- [Pandas](http://pandas.pydata.org)
- [matplotlib](http://matplotlib.org/)
- [scikit-learn](http://scikit-learn.org/stable/)
- [seaborn](https://seaborn.pydata.org/)

All these libraries are available in Jupyter Notebook[https://jupyter.org/].

### Code

The python code required to run the project is contained in [Capstone project.ipynb] notebook file.The data used is provided in [diabetes.csv] file.


### Data
The movie dataset consists of 2000 data points, with 9 features.The dataset is downloaded from kaggle
[https://www.kaggle.com/johndasilva/diabetes]


The list of columns is as follows:
Pregnancies 
Glucose 
BloodPressure - 
SkinThickness
Insulin
BMI 
DiabetesPedigreeFunction
Age
Outcome

The target variable is Outcome.
